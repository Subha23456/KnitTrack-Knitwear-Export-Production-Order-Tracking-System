# deployment.md — Deployment & Local Run Guide
**Project:** KnitTrack Tiruppur — Knitwear Exporter's Production Order Tracking System  
**Framework:** React 19 + Express + SQLite (better-sqlite3) Full-Stack Application  
**GitHub Repository:** https://github.com/Subha23456/Knitwear-exporter-s-production-order-tracking-app-with-buyer-view/  
**Live URL:** https://ais-pre-a2bkzzm4scpewhcprbh3ck-235016284191.asia-southeast1.run.app  

---

## 1. How to Run Locally Step-by-Step

### Prerequisites
- Node.js version 18.x or 20.x+
- npm version 9.x+

### Step 1: Clone the Repository
```bash
git clone https://github.com/Subha23456/Knitwear-exporter-s-production-order-tracking-app-with-buyer-view.git
cd Knitwear-exporter-s-production-order-tracking-app-with-buyer-view
```

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Optional: Populate `GEMINI_API_KEY` with your Gemini API key for live LLM translation. If not provided, the application automatically uses its built-in deterministic Tamil NLP classifier with zero errors.

### Step 4: Run the Application in Development Mode
```bash
npm run dev
```
The server will start at:
`http://localhost:3000`

### Step 5: Run Automated Tests & Production Build
```bash
npm test        # Runs 24 Vitest tests covering run-rate math, buyer isolation, audits, and Tamil NLP
npm run lint    # Validates TypeScript types (tsc --noEmit)
npm run build   # Produces optimized production bundle in dist/
npm run start   # Starts the production server (node server.ts)
```

---

## 2. Environment Variables

The application references the following environment variables (defined in `.env.example`). Never commit secret keys or production credentials to the repository.

| Variable Name | Purpose | Required / Optional |
| :--- | :--- | :--- |
| `GEMINI_API_KEY` | Server-side Gemini 3.8 Flash API key for Tamil note translation & root-cause categorization. | Optional (app has built-in offline NLP fallback) |
| `PORT` | HTTP port on which the Express server listens (default: 3000). | Optional (defaults to 3000) |
| `APP_URL` | Self-referential URL where the applet is hosted on Cloud Run. | Injected by AI Studio |
| `NODE_ENV` | `development` or `production`. | Optional |

---

## 3. Demo Login Details for Reviewer

The app includes a 1-click **Quick Role Switcher** in the top navigation bar, and also supports standard email/password authentication:

| Persona / Role | Name | Email | Password | What to Verify in This Role |
| :--- | :--- | :--- | :--- | :--- |
| **Senior Merchandiser** | Priya Rajan | `priya.rajan@companya-knits.com` | `tiruppur123` | - Full Production Board with Green/Amber/Red traffic lights.<br>- Click "+ New Order" to create PO with TNA milestone schedule.<br>- Click Calculator icon to inspect run-rate mathematical proof.<br>- Click Sparkles icon to review & override AI categories and confirm delay warnings before buyers see them.<br>- Click History icon to revise dates and log immutable compliance audits. |
| **Floor Supervisor** | Murugan Kandasamy (முருகன்) | `murugan.unit1@companya-knits.com` | `tiruppur123` | - Mobile-first touch interface with Tamil toggle (தமிழ் / English).<br>- Test voice note transcription or enter Tamil floor notes.<br>- Inspect live Gemini AI translation & root-cause preview.<br>- Click "Offline" button to test offline queuing and 1-tap sync. |
| **Buyer (Company B - UK)** | John Smith | `j.smith@companyb-retail.co.uk` | `tiruppur123` | - **Strict Multi-Tenant Isolation:** Accesses ONLY orders for Company B (`B-PO-88213`, `B-PO-88240`).<br>- Company C's styles and volumes are completely invisible.<br>- Inspect milestone progress, verified photos, and compliance audit trail.<br>- Download Weekly Status Report (Excel/CSV). |
| **Buyer (Company C - Germany)** | Hans Weber | `h.weber@companyc-textil.de` | `tiruppur123` | - **Strict Multi-Tenant Isolation:** Accesses ONLY PO `C-PO-0488` (Kids printed tee, yellow).<br>- Company B's styles and volumes are completely hidden. |
| **Managing Director (Executive)** | K. Shanmugam | `ks@companya-knits.com` | `tiruppur123` | - Executive dashboard tracking the ₹1.08 Crore financial risk model.<br>- Rupee exposure calculation: ₹3.50L air freight + 5% discount risks.<br>- Tracking progress toward the 5% late shipment target.<br>- Authorized to execute protected database resets. |

---

## 4. Database Storage & Persistence
- Data is stored in SQLite format at `data/knittrack.db` using WAL mode.
- Tables: `users`, `sessions`, `orders`, `milestones`, `daily_logs`, and `date_change_audits`.
- Initial seed data matching the client brief is populated automatically if the database file is newly initialized.
